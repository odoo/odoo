"""
This package contains the portions of the library used only when
implementing an OpenID consumer.
"""

__all__ = ['consumer', 'discover']

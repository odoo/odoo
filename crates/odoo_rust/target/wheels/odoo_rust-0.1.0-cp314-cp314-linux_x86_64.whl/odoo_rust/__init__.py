from .odoo_rust import *

__doc__ = odoo_rust.__doc__
if hasattr(odoo_rust, "__all__"):
    __all__ = odoo_rust.__all__
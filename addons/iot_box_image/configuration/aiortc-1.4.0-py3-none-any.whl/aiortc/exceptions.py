class InternalError(Exception):
    pass


class InvalidStateError(Exception):
    pass
